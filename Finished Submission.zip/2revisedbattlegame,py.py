# declare the names of your players
wizard = "Wizard"
elf = "Elf"
human = "Human"

# declare the health that your players start out with
wizard_hp = 70
elf_hp = 100
human_hp = 150

# declare the amount of damage that your players can do
wizard_damage = 150
elf_damage = 100
human_damage = 20

dragon_damage = 50
dragon_hp = 300

# your health and your character
character = ''
my_hp = ''


# This is how you choose which characters
while True:
    print("1 Wizard")
    print("2 Elf")
    print("3 Human")
    character = input("Choose a Character: ")
    if (character == "1"):
        character = wizard
        my_damage = wizard_damage
        my_hp = wizard_hp
        break
    elif(character == "2"):
        character = elf
        my_damage = elf_damage
        my_hp = elf_hp
        break
    elif(character == "3"):
        character = human
        my_damage = human_damage
        my_hp = human_hp
        break
    else:
        print("Unknown character")


print("You have chosen the character:", character)
print("Health: ", my_hp)
print("Damage: ", my_damage)
print()


# this will delete your hp of each character because they are fighting!!!
while True:

    dragon_hp = dragon_hp - my_damage
    print(character, "has damaged the Dragon!")
    print("The Dragon's hitpoints are: ", dragon_hp)
    print()

    if(dragon_hp <= 0):
        print("The Dragon has lost the battle.")
        break
    print("The Dragon strikes back at the ", character)
    my_hp = my_hp - dragon_damage
    print("The", character, "'s hitpoints are now : ", my_hp)
    print()

    if(my_hp <= 0):
        print("The ", character, " has lost the battle.")
        break
